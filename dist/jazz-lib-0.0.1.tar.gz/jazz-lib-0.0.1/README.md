This app lets you search jazz records.
